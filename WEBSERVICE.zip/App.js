import logo from './logo.svg';
import './App.css';

import Navi from './components/Navi';
import FORMU from './components/FORMU';
function App() {
  return (
    <div className="App">

      <p>
        PRUEBA
      </p>
      <div>

        <p>
          CUADRANGULAR

        </p>
        Equipos 
        <Navi></Navi>

        <FORMU></FORMU>

      </div>

    </div>

  );
}

export default App;
