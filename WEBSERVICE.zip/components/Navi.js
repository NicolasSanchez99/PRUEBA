
import React from 'react';
import {  Form} from 'react-bootstrap';

class Navi extends React.Component{
    render(){
        return(
            <Form.Control type="text" placeholder="Readonly input here..." readOnly />

            );
    }
}

export default Navi;