import React from 'react';
import { Button} from 'react-bootstrap';
class FORMU extends React.Component{
    render(){
        return(
            <Button variant="primary" size="lg" active>  </Button>
        )
    }
}

export default FORMU;